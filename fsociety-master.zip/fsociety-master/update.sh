#    ______              _      _           _______
#   |  ____|            (_)    | |         |__   __|
#   | |__ ___  ___   ___ _  ___| |_ _   _     | | ___  __ _ _ __ ___
#   |  __/ __|/ _ \ / __| |/ _ \ __| | | |    | |/ _ \/ _` | '_ ` _ \
#   | |  \__ \ (_) | (__| |  __/ |_| |_| |    | |  __/ (_| | | | | | |
#   |_|  |___/\___/ \___|_|\___|\__|\__, |    |_|\___|\__,_|_| |_| |_|
#                                    __/ |
#                                   |___/
#
#Greet's To
#IcoDz - Canejo
#Tool For Hacking
#Authors : Manisso

clear

sudo chmod +x /etc/

clear

sudo chmod +x /usr/share/doc

clear

sudo rm -rf /usr/share/doc/fsociety/

clear

cd /etc/

clear

sudo rm -rf /etc/Manisso

clear

mkdir Manisso

clear

cd Manisso

clear

git clone https://github.com/Manisso/fsociety.git

clear

cd fsociety

clear

sudo chmod +x install.sh

clear

./install.sh

clear
